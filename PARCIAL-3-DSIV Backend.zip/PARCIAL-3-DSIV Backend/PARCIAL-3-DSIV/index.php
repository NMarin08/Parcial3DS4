<?php include 'functions.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parcial N2</title>
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript" src="jquery.js"></script>
</head>

<body>
    <div id="custom-alert" class="custom-alert">
		<span id="alert-text"></span>
	</div>
    <?php 
        if(isset($_POST['name']) && $_POST['name'] !=''){
            $insert_array = array('name' => $_POST['name'], 'email' => $_POST['email'], 'message' => $_POST['message']);
            $result = insert('contact', $insert_array);
        }
    ?>
    <header>
        <nav class="menu-container">
            <ul class="menu-icon">
                <li class="bar"></li>
                <li class="bar"></li>
                <li class="bar"></li>
                </div>
                </div>
    </header>
    <section class="section-one">
        <div class="margins">
            <h1>League of Legends</h1>
            <div class="img-container"></div>
            <p>League of Legends es un juego de estrategia por equipos en el que dos equipos de cinco campeones se enfrentan para ver quién destruye antes la base del otro. Elige de entre un elenco de 140 campeones para realizar jugadas épicas, asesinar rivales y derribar torretas para alzarte con la victoria.</p>
        </div>
    </section>

    <section class="section-two">
        <div class="margins">
            <div class="column-left">
                
                <div class="img-container"></div>
            </div>
            <div class="column-right">
                <h2>Conoce más</h2>
                <p>A LA CONQUISTA DE LA JUNGLA</p> 
                <p>Entre las calles se encuentra la jungla, en la que habitan monstruos neutrales y plantas mágicas. Los dos tipos de monstruos más importantes son el Barón Nashor y los dragones. Acabar con estas unidades otorgará a tu equipo mejoras únicas y, en ocasiones, te ayudará a darle la vuelta a la partida.</p>
                <p>DESTRUYE LA BASE</p>
                   <p>El nexo es el corazón de las bases de ambos equipos. Destruye el nexo enemigo para ganar la partida.
                 <p>DESPEJA EL CAMINO</p>   
<p>Tu equipo debe despejar al menos un carril para llegar al nexo enemigo. En tu camino se interponen estructuras defensivas denominadas torretas e inhibidores. Cada carril cuenta con tres torretas y un inhibidor, mientras que cada nexo está protegido por dos torretas.</p>
                
            </div>
        </div>
    </section>
    <section class="section-three">
        <div class="margins">
            <h2 class="title">En cada partida podrás ver lo siguiente</h2>
            <div class="info-container">
                <div class="column-left">
                    <div class="card">
                        <img class="icons" src="img/nexo.jpeg" alt="">
                        <h3>EL NEXO</h3>
                        <p>Es la base de los equipos. Cada equipo tiene un nexo y para ganar hay que destruir el del equipo contrario. Del nexo además se generan los súbditos (o minioms) y detrás de este está la fuente, donde se recupera vida y maná rápido (a parte del acceso a la tienda).</p>
                    </div>
                    <p class="description">Durante las partidas de League of Legends los personajes se van volviendo más y más fuertes al ganar experiencia y conseguir oro, dos factores a los que nunca hay que dejar de prestar atención</p>
                </div>
                <div class="column-right">
                    <p class="description">El oro: es la divisa dentro de las partidas que te permitirá comprar objetos para tu campeón. Puedes acumular oro matando unidades enemigas, destruyendo estructuras o realizando asistencias.</p>
                    <div class="card">
                        <img class="icons" src="img/torretas.jpeg" alt="" >
                        <h3>TORRETAS</h3>
                        <p class="">Son estructuras dispersas por el mapa que infligen daño a los súbditos y campeones enemigos. Además ofrecen un campo de visión limitado. Hay que destruir las enemigas para poder avanzar.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="section-four">
        <div class="gallery">
            <img src="img/arcana.jpg" alt="">
            <img src="img/azulito.jpeg" alt="">
            <img src="img/god.jpg" alt="">
            <img src="img/bestskins.jpg" alt="">
        </div>
        <p>La experiencia: se consigue asesinados unidades y campeones enemigos, asistiendo a tus compañeros en asesinatos y destruyendo las estructuras defensivas de los rivales. Al ganar determinadas cantidades de EXP, los campeones suben de nivel, lo que les permite desbloquear habilidades o mejorarlas para aumentar sus estadísticas básicas.</p>
        <button>Leer más</button>
    </section>
    <section class="section-five">
        <div class="margins">
            <h2>Clases de los personajes</h2>
            <div class="card-container">
                <div class="card">
                    <img class="icons" src="assets/aniquiladores.jpeg"  alt="">
                    <h3>Aniquiladores</h3>
                    <p> Son una clase de campeones centrados en el daño de ráfaga.
                        </p>
                </div>
                <div class="card">
                    <img class="icons" src="assets/controladores.jpeg" alt="">
                    <h3>Controladores</h3>
                    <p>Están diseñados para ayudar a sus aliados con una potente utilidad y control de multitudes.</p>
                </div>
                <div class="card">
                    <img class="icons" src="assets/luchadores.jpeg" alt="">
                    <h3>&nbsp;&nbsp;&nbsp;Luchadores</h3>
                    <p> Son combatientes especialistas en el corto alcance o melee, fuertes y resistentes.</p>
                </div>
                <div class="card">
                    <img class="icons" src="assets/magos.jpeg" alt="">
                    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Magos</h3>
                    <p> Están enfocados en el gran alcance y las capacidades de daño en área.</p>
                </div>
                <div class="card">
                    <img class="icons" src="assets/tanques.jpeg" alt="">
                    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tanques</h3>
                    <p>Son los personajes comúnmente preparados para ejercer como los defensas de un equipo.</p>
                </div>
                <div class="card">
                    <img class="icons" src="assets/tiradores.jpeg" alt="">
                    <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Tiradores</h3>
                    <p>Diseñados para el combate a distancia, con un poder basado casi exclusivamente en ataques básicos.</p>
                </div>
            </div>

        </div>
    </section>

    <section class="section-seven">
        <div class="card">
            <h3>COMIENZA TU</h3>
            <h2>LEYENDA</h2>
            <h3>¿No conoces League of Legends? </h3>
            <p>Aquí encontrarás un buen resumen <br> de los fundamentos del modo <br> de juego más popular.</p>
            
            <button>Empezar</button>
        </div>
        <div class="card">
            <h3>APLASTA CON</h3>
            <h2>ESTILO</h2>
            <h3>Personaliza tu experiencia <br>con aspectos para tus campeones<br>  favoritos.</h3>
            <br><br><br><br>
            <button>Jugar ahora</button>
        </div>
    </section>
    <section class="section-eight">
        <div class="margins">
            <h2>Personajes</h2>
            <div class="container-right">
                <div class="card mary">
                    
                </div>
                <div class="card linda">
                    
                </div>
            </div>
            <div class="container-left">
                <div class="card paul">
                    
                </div>
                <div class="card nick">
                    
                </div>
            </div>
        </div>
    </section>
    <section class="section-nine">
        <div class="margins">
            <h2>Información de patrocinadores</h2>
            <div class="container">
                <h3>ACERCA DE LOL</h3>
                <h3>WEB LOL ESPORTS</h3>
                <h3>ASISTENCIA</h3>
                <h3>ESTADO DEL SERVIDOR</h3>
            </div>
            <div class="container">
                <h3>RIOT GAMES</h3>
                <h3>AVISO DE PRIVACIDAD</h3>
                <h3>TÉRMINOS DE USO</h3>
                <h3>POLÍTICA DE PRIVACIDAD</h3>
            </div>
        </div>
    </section>
    <section class="section-ten margins">
        <form action="" method="post">
            <div>
                <label for="">NAME</label>
                <input type="text" name="name" id="" placeholder="Enter your Name">
            </div>
            <div><label for="">EMAIL</label>
                <input type="email" name="email" placeholder="Enter a valid email address">
            </div>
            <div><label for="">MESSAGE</label>
                <textarea name="message" id="" cols="50" rows="10" placeholder="Enter Your Message"></textarea>
            </div>
            <div>
                <button type="submit" name="submit" class="sub">Submit</button>
            </div>
        </form>
        <div class="div">
            <P>
                Descárgate la aplicación de LoL para seguir en contacto con tus amigos y estar al día de todas las novedades del juego y de los esports.</P>
        </div>
    </section>
    <footer>
        <p>Sample text. Click to select the text element</p>
        <p class="margin-p">Website Templates created with my hands!!!!.</p>
    </footer>
</body>

</html>