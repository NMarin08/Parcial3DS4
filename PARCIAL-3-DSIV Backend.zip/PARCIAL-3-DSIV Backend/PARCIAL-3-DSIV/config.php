<?php
$server = 'localhost';
$user = 'root';
$pwd = '';
$database = 'dsiv';

$conn = $con = mysqli_connect($server, $user, $pwd, $database);
if(!$conn){
    echo 'error: ' . mysqli_connect_error();
}
?>