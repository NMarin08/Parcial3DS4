
<?php 
session_start();
include 'config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// insert data
function insert($tb_name, $data)
{
    global $conn;
    unset($data['action']);
    $keys = '';
    $vals = '';
    foreach ($data as $key => $val) {
        $keys .= '`' . $key . '`,';
        if (is_array($val))
            $val = implode($val);
        $val = mysqli_real_escape_string($conn, $val);
        $vals .= "'" . $val . "'" . ',';
    }
    $keys = rtrim($keys, ',');
    $vals = rtrim($vals, ',');
    $qry = "INSERT INTO `$tb_name` ($keys) VALUES ($vals)";
    $result = mysqli_query($conn, $qry); // Execute the query
    if ($result) {
        echo '<script>';
        echo 'document.getElementById("alert-text").innerHTML = "Data Save successfully!";';
        echo 'var customAlert = $("#custom-alert");';
        echo 'customAlert.addClass("success show");';
        echo 'setTimeout(function(){';
        echo '  customAlert.fadeOut("slow", function() {';
        echo '    customAlert.removeClass("show");';
        echo '  });';
        echo '}, 5000);'; 
        echo '</script>';
    } else {
        echo '<script>';
        echo 'document.getElementById("alert-text").innerHTML = "Something Wrong!";';
        echo 'var customAlert = $("#custom-alert");';
        echo 'customAlert.addClass("error show");';
        echo 'setTimeout(function(){';
        echo '  customAlert.fadeOut("slow", function() {';
        echo '    customAlert.removeClass("show");';
        echo '  });';
        echo '}, 3000);'; 
        echo '</script>';
    }
    return $result; 
}


?>

